// ═══════════════════════════════════
// LOGIN.JS
// ═══════════════════════════════════

let users = Storage.get("cs-users") || [];
let confirmDelete = null;

function render() {
  const list = document.getElementById("users-list");
  const label = document.getElementById("new-label");
  list.innerHTML = "";

  if (users.length > 0) {
    label.textContent = "Ou entre un nouveau prénom";
    const title = document.createElement("p");
    title.style.cssText = "font-weight:bold;font-size:15px;color:var(--text);margin-bottom:14px;text-align:center";
    title.textContent = "Choisis ton profil";
    list.appendChild(title);

    users.forEach(u => {
      const row = document.createElement("div");
      row.className = "user-row";

      if (confirmDelete === u) {
        row.innerHTML = `
          <span style="flex:1;font-weight:bold;font-size:14px;color:var(--text)">Supprimer ${u} ?</span>
          <button class="btn btn-danger btn-small" onclick="deleteUser('${u}')">Oui</button>
          <button class="btn btn-outline btn-small" onclick="cancelDelete()">Non</button>`;
      } else {
        row.innerHTML = `
          <button class="user-btn" onclick="selectUser('${u}')">
            <span style="font-size:28px">🐾</span> ${u}
          </button>
          <button class="del-btn" onclick="askDelete('${u}')">🗑</button>`;
      }
      list.appendChild(row);
    });

    // Séparateur si déjà des utilisateurs
    const sep = document.createElement("div");
    sep.className = "section-sep";
    sep.textContent = "ou";
    list.appendChild(sep);
  } else {
    label.textContent = "Entre ton prénom pour commencer";
  }
}

function selectUser(name) {
  Storage.set("cs-current-user", name);
  goTo("accueil.html");
}

function addUser() {
  const input = document.getElementById("new-input");
  const name = input.value.trim();
  if (!name) return;
  if (!users.includes(name)) {
    users.push(name);
    Storage.set("cs-users", users);
  }
  selectUser(name);
}

function askDelete(name) {
  confirmDelete = name;
  render();
}

function cancelDelete() {
  confirmDelete = null;
  render();
}

function deleteUser(name) {
  users = users.filter(u => u !== name);
  Storage.set("cs-users", users);
  // Supprimer ses données
  Storage.remove(`cs-${name}-profiles`);
  Storage.remove(`cs-${name}-history`);
  Storage.remove(`cs-${name}-calendar`);
  confirmDelete = null;
  render();
}

// Redirect si déjà connecté
if (getCurrentUser()) {
  goTo("accueil.html");
}

render();
